﻿namespace StudentSystem.Common
{
    public static class Config
    {
        public const string ConnectionString = "Server=THEBEAST;Database=StudentsSystem;Integrated Security=True;Encrypt=False;";
    }
}
