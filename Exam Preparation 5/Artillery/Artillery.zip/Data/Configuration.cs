﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=THEBEAST;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
