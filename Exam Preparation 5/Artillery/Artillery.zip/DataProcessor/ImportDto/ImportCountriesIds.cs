﻿namespace Artillery.DataProcessor.ImportDto
{
    using Newtonsoft.Json;
    public class ImportCountriesIds
    {
        [JsonProperty("Id")]
        public int Id { get; set; }
    }
}
