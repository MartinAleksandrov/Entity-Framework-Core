﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoices.Shared
{
    public class Const
    {
        public const decimal ProductPriceMaxValue = 1000m;

        public const decimal ProductPriceMinValue = 5m;

    }
}
